
Acesse a pasta do projeto e execute no terminal para todas as dependencias sejam instaladas:
    bundle install 

Para iniciar o teste execute no terminal:
bundle exec cucumber buscar_produto.feature
