class BaseScreen

    def clicar_elemento(elemento)
        byebug
        puts "cheguei aqui na base"
        puts elemento
        find('#btn-age-yes').click
    end

    def preencher_campo(elemento, valor)
        find(elemento).send_keys(valor)
    end

    def existe_elemento?(elemento)
        visivel = find(elemento).visible?
        visivel
     end

end
