require '/Users/karlapsouza/Projetos/zedelivery/zedelivery-master/features/support/page_helper.rb'
require 'capybara'
require 'capybara/cucumber'
require 'byebug'
require 'selenium-webdriver'

class BuscarProdutoScreen
    
    elemento_tela =[
        id_sim_maior_18: '#btn-age-yes', 
        class_botao_entrega: '.sc-bsbRJL.gEUOKk', 
        id_campo_endereco: '#pacInput', 
        class_botao_verproduto: '.sc-hzDkRC.eDcQTW', 
        class_selecionar_endereco: '.sc-hwwEjo.jnICUn', 
        id_campo_numero: '#numberInput',
        class_campo_complemento: '.sc-eqIVtm.ccgfQa',
        class_campo_tipoproduto: '.user-dropdown-select',
        id_campo_busca: '.search-bar',
        id_lupa: '#glass-product',
        class_selecionar_produto: '.product-card display-flex.column.flex',
        class_campo_quantidade: '.user-text-input-wrapped',
        class_label_preco: '.products-cart-price',
        class_botao_fecharconta: '.products-cart-button',
    ] 
    
    #cap = Capybara::Node::Element

    def verifica_idade
        byebug
        find('#btn-age-yes')
       # if existe_elemento?('#btn-age-yes')
        #    elemento = clicar_elemento(elemento_tela[:id_sim_maior_18])
         #   fail "Não foi possível clicar no elemento para confirmar que tenho mais de 18 anos" unless elemento.is_a?cap
        #end
    end

    def preencher_endereco(rua, numero, complemento)
        if existe_elemento?(elemento_tela[:class_botao_entrega])
            preencher_campo(elemento_tela[:id_campo_endereco], rua)
            clicar_elemento(elemento_tela[:class_selecionar_endereco])
        end
        if existe_elemento?(elemento_tela[:id_campo_numero])
            preencher_campo(elemento_tela[:id_campo_numero], numero)
            preencher_campo(elemento_tela[:class_campo_complemento], complemento)
        end
        clicar_class(elemento_tela[:class_botao_verproduto])
        fail "Não foi possível clicar no bot±ao ver produto" unless elemento.is_a?cap
    end

    def buscar_produto(produto)
        preencher_campo(elemento_tela[:id_campo_busca], produto)
        clicar_elemento(elemento_tela[:id_lupa])
        fail "Não foi possível clicar no elemento lupa" unless elemento.is_a?cap
    end

    def selecionar_produto(quantidade)
        clicar_elemento(elemento_tela[:class_selecionar_produto])
        preencher_campo(elemento_tela[:class_campo_quantidade], quantidade)
        if(elemento_tela[:class_label_preco] > 15)
            clicar_elemento(elemento_tela[:class_botao_fecharconta])
            fail "Não foi possível clicar no elemento para confirmar a compra" unless elemento.is_a?cap
        end
    end
    
end