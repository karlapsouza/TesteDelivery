
Dado(/^que eu acesso o site do Zé delivery$/) do
  site = "https://www.ze.delivery/"
  visit site
end

Quando(/^preencho as informações necessárias para buscar pelo produto "([^"]*)" e informo a quantidade "([^"]*)"$/) do |produto, quantidade|
  byebug
  buscar = BuscarProdutoScreen.new
  teste = find('#btn-age-yes')
  find('#btn-age-yes')
  byebug
  buscar.verifica_idade()
  buscar.preencher_endereco('Av. Paulista', '77', 'Ap. 55')
  buscar.buscar_produto(produto)
  buscar.selecionar_produto(quantidade)
end


